package domain;

public class PostTypeVo {
	private int post_type_idx;
	private String post_type;
	
	public int getPost_type_idx() {
		return post_type_idx;
	}
	public void setPost_type_idx(int post_type_idx) {
		this.post_type_idx = post_type_idx;
	}
	public String getPost_type() {
		return post_type;
	}
	public void setPost_type(String post_type) {
		this.post_type = post_type;
	}
	
	
}
