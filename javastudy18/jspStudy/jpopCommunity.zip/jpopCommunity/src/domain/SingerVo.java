package domain;

public class SingerVo {
	private int singer_idx;
	private String singer;
	private String singer_img;
	
	public int getSinger_idx() {
		return singer_idx;
	}
	public void setSinger_idx(int singer_idx) {
		this.singer_idx = singer_idx;
	}
	public String getSinger() {
		return singer;
	}
	public void setSinger(String singer) {
		this.singer = singer;
	}
	public String getSinger_img() {
		return singer_img;
	}
	public void setSinger_img(String singer_img) {
		this.singer_img = singer_img;
	}
	
	
}
